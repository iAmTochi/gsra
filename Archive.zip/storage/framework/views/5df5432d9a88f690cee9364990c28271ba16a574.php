<?php $__env->startSection('content'); ?>

    <!-- ======================= Verify email Detail ======================== -->
    <section class="middle">
        <div class="container">
            <div class="row align-items-start justify-content-center">

                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="text-center mb-5 p-2">
                        <a class="nav-brand" href="<?php echo e(route('home')); ?>">
                            <img src="assets/img/logo.png" class="logo" alt="" />
                        </a>
                    </div>


                    <form class="border p-3 rounded" method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="eltio_k2">
                                    <a href="#">
                                        Forgot your password? No problem. Just let us know your email address,
                                        and we will email you a password reset link that will allow you to choose a new one.
                                    </a>
                                </div>
                            </div>
                        </div>



                <div class="eltio_k2">
                        <?php if(session('status')): ?>
                            <div class="mb-4 font-medium text-sm text-green-600 theme-cl">
                                <?php echo e(__('We have emailed your password reset link!')); ?>

                            </div>
                        <?php endif; ?>
                </div>
                        <div class="form-group">
                            <input type="text" value="<?php echo e(old('email')); ?>" name="email" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email *">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-md full-width theme-bg text-light fs-md ft-medium">Email Password Reset Link</button>
                        </div>
                        <?php if(session('status') == 'verification-link-sent'): ?>
                            <div class="mb-4 font-medium theme-cl text-sm text-green-600">
                                <?php echo e(__('A new verification link has been sent to the email address you provided during registration.')); ?>

                            </div>
                        <?php endif; ?>
                    </form>


                </div>
            </div>
        </div>
    </section>
    <!-- ======================= Verify email End ======================== -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gsra/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>