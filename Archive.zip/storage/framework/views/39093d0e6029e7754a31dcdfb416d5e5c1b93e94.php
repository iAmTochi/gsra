<?php $__env->startSection('content'); ?>
    <!-- ======================= Verify email Detail ======================== -->
    <section class="middle">
        <div class="container">
            <div class="row align-items-start justify-content-center">

                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="text-center mb-5 p-2">
                        <a class="nav-brand" href="<?php echo e(route('home')); ?>">
                            <img src="<?php echo e(asset('assets/img/logo.png')); ?>" class="logo" alt="" />
                        </a>
                    </div>


                    <form class="border p-3 rounded" method="POST" action="<?php echo e(route('password.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <!-- Password Reset Token -->
                            <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">

                        <div class="form-group">
                            <input type="text" value="<?php echo e(old('email',$request->email)); ?>" name="email" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email *" required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row">
                            <div class="form-group col-12">
                                <label>Password</label>
                                <input required type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="Password*">
                                <span role="alert" class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            </div>

                            <div class="form-group col-12">
                                <label>Confirm Password</label>
                                <input required type="password" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" class="form-control <?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" placeholder="Confirm Password*">
                                <span role="alert" class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                </span>
                            </div>

                            <div class="form-group col-12">
                                <button type="submit" class="btn btn-md full-width theme-bg text-light fs-md ft-medium">Reset Password</button>
                            </div>
                        </div>

                    </form>


                </div>
            </div>
        </div>
    </section>
    <!-- ======================= Verify email End ======================== -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gsra/resources/views/auth/reset-password.blade.php ENDPATH**/ ?>