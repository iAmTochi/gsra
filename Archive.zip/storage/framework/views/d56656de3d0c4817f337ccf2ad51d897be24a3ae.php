<div class="collapse" id="MobNav">
    <div class="dashboard-nav">
        <div class="dashboard-inner">
            <ul data-submenu-title="Main Navigation">
                <li class="active"><a href="<?php echo e(route('login')); ?>"><i class="lni lni-dashboard mr-2"></i>Dashboard</a></li>
                <li class="accordion">
                    <a href="" data-toggle="collapse" data-target="#manage-job" aria-expanded="true" aria-controls="manage-job"><i class="lni lni-add-files mr-2"></i>Manage Jobs</a>
                    <ul id="manage-job" class="collapse">
                        <li><a href="<?php echo e(route('jobs.index')); ?>"><i class="lni lni-files mr-2"></i>View All Jobs<span class="count-tag bg-warning">4</span></a></li>
                        <li><a href="<?php echo e(route('jobs.create')); ?>"><i class="lni lni-add-files mr-2"></i>Post New Job </a></li>
                    </ul>

                </li>
                <li class="accordion">
                    <a href="" data-toggle="collapse" data-target="#manage-user" aria-expanded="true" aria-controls="manage-user"><i class="lni lni-add-files mr-2"></i>Manage Users</a>
                    <ul id="manage-user" class="collapse">
                        <li><a href="dashboard-shortlisted-resume.html"><i class="lni lni-bookmark mr-2"></i>View All Users<span class="count-tag bg-warning">4</span></a></li>
                        <li><a href="dashboard-packages.html"><i class="lni lni-mastercard mr-2"></i>Add New User</a></li>

                    </ul>

                </li>
                <li class="accordion">
                    <a href="" data-toggle="collapse" data-target="#manage-applicant" aria-expanded="true" aria-controls="manage-applicant"><i class="lni lni-briefcase mr-2"></i>Manage Applicants</a>
                    <ul id="manage-applicant" class="collapse">
                        <li><a href="dashboard-shortlisted-resume.html"><i class="lni lni-files mr-2"></i>View All Applicants<span class="count-tag bg-warning">4</span></a></li>
                    </ul>

                </li>
                <li><a href="dashboard-messages.html"><i class="lni lni-envelope mr-2"></i>Messages<span class="count-tag">4</span></a></li>

                <li><a href="dashboard-shortlisted-resume.html"><i class="lni lni-bookmark mr-2"></i>BookmarkResumes<span class="count-tag bg-warning">4</span></a></li>




            </ul>
            <ul data-submenu-title="My Accounts">
                <li><a href="dashboard-my-profile.html"><i class="lni lni-user mr-2"></i>My Profile </a></li>
                <li><a href="dashboard-change-password.html"><i class="lni lni-lock-alt mr-2"></i>Change Password</a></li>
                <li><a href="javascript:void(0);"><i class="lni lni-trash-can mr-2"></i>Delete Account</a></li>
                <li>
                    <a href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();">
                        <i class="lni lni-power-switch mr-1"></i> Logout
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gsra/resources/views/partial/_admin_sidebar.blade.php ENDPATH**/ ?>