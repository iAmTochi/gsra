

<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->

<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/slick.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/slider-bg.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/smoothproducts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/snackbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jQuery.style.switcher.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<!-- ============================================================== -->
<!-- This page plugins -->
<!-- ============================================================== -->

</body>

</html>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gsra/resources/views/partial/_foot.blade.php ENDPATH**/ ?>