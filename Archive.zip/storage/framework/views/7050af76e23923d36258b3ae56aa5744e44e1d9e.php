<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8" />
    <meta name="author" content="Dynaton Digital Solutions" />
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'You are Good')); ?> - Creative Job Board HTML Template</title>

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('assets/css/styles.css')); ?>" rel="stylesheet">

</head>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gsra/resources/views/partial/head.blade.php ENDPATH**/ ?>