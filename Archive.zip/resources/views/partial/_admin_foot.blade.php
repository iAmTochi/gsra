{{--<div class="row" style="position: fixed; bottom: 0px">--}}
<div class="row">
    <div class="col-md-12">
        <div class="py-3">©  {{ date('Y') }} Global Skills Recruitment Agency Limited.</div>
    </div>
</div>
