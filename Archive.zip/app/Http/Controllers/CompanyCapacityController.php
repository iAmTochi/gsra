<?php

namespace App\Http\Controllers;

use App\Models\CompanyCapacity;
use Illuminate\Http\Request;

class CompanyCapacityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CompanyCapacity  $companyCapacity
     * @return \Illuminate\Http\Response
     */
    public function show(CompanyCapacity $companyCapacity)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CompanyCapacity  $companyCapacity
     * @return \Illuminate\Http\Response
     */
    public function edit(CompanyCapacity $companyCapacity)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CompanyCapacity  $companyCapacity
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CompanyCapacity $companyCapacity)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CompanyCapacity  $companyCapacity
     * @return \Illuminate\Http\Response
     */
    public function destroy(CompanyCapacity $companyCapacity)
    {
        //
    }
}
